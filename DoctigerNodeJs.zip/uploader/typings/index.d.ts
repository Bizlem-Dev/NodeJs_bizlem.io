/// <reference path="globals/body-parser/index.d.ts" />
/// <reference path="globals/express/index.d.ts" />
/// <reference path="globals/mocha/index.d.ts" />
/// <reference path="globals/multer/index.d.ts" />
/// <reference path="globals/node/index.d.ts" />
/// <reference path="globals/should/index.d.ts" />
/// <reference path="globals/supertest/index.d.ts" />
