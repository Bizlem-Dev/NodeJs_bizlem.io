﻿var Express = require('express');
var multer = require('multer');
var fs = require('fs');
var formidable = require('formidable');
var bodyParser = require('body-parser');
var mammoth = require("mammoth");
var app = Express();
var HtmlDocx = require('html-docx-js');
var fs = require('fs');

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(bodyParser.json());

var Storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "../assets/docs/");
    },
    filename: function (req, file, callback) {
        callback(null, file.fieldname + "_" + Date.now() + "_" + file.originalname);
    }
});

var upload = multer({ storage: Storage }).array("imgUploader", 3); //Field name and max count

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/index.html");
});

app.post("/api/uploadform", function (req, res) {
    upload(req, res, function (err) {
        if (err) {
            return res.end("Something went wrong!");
        }
        return res.end("File uploaded sucessfully!.");
    });
});

app.post('/api/uploadfile', function (req, res) {
    var form = new formidable.IncomingForm();

    form.parse(req);

    form.on('fileBegin', function (name, file) {
        // file.path = __dirname + '/storage/' + file.name;
        file.path = __dirname + '/../assets/docs/' + file.name;
        console.log('path here--> '+ file.path)
    });

    form.on('file', function (name, file) {
        var path = __dirname + '/../assets/docs/' + file.name
        console.log('Uploaded file name' + file.name);
        var fileExt = file.name.split('.').pop();
       // file convertion 
        if(fileExt === 'docx'){
            var tbspval = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
            var options = {
                styleMap: [
                    "p[style-name='Code'] => pre:separator('\n')",
                    "p[style-name='center'] => center",
                    "p[style-name='Heading 1'] => p:fresh > h1:fresh",
                    "p[style-name='Heading 2'] => p:fresh > h2:fresh",
                    "p[style-name='Heading 3'] => p:fresh > h3:fresh",
                    "p[style-name='Heading 4'] => p:fresh > h4:fresh",
                    "p[style-name='Heading 5'] => p:fresh > h5:fresh",
                    "p[style-name='Heading 6'] => p:fresh > h6:fresh"
                ],
                transformDocument: transformElement
            }
            return mammoth.convertToHtml({ path: __dirname + '/../assets/docs/' + file.name },options)
            .then(function (result) {
                
                var html = result.value; // The generated HTML
                var messages = result.messages; // Any messages, such as warnings during conversion
                console.log(messages);
                return   res.end(result.value.replace(/\t/g,tbspval));
            }).catch( error => {
                console.log( 'onRejected function called: ' + error.message );
                  return   res.status(500).end('something went wrong. Please try again later');
              })
            .done();
        } else if(fileExt === 'txt'){
            fs.readFile(__dirname + '/../assets/docs/' + file.name, 'utf8', function(err, contents) {
                return   res.end(contents.replace(/\n/g, '<br />'));
            });
        } 
        else{
            return   res.status(500).end('file type not supported');
        }

      

    });

    function transformElement(element) {
        if (element.children) {
          element.children.forEach(transformElement);
        }
        if (element.type === "paragraph") {
          if (element.alignment === "center" && !element.styleId) {
            element.styleName = "center";
          }
        }
        return element;
      }

});

app.post("/api/savetodisk", function (req, res) {

   var html = req.body.content;
   console.log(html);
    var docx = HtmlDocx.asBlob(html);
    var filename =  'document_' + getRandomSalt() + '.docx';
    fs.writeFile(__dirname + '/../assets/docs/' + filename,docx, function (err){
       if (err) return console.log(err);
       console.log('done');
       return   res.status(200).end('success');
    });

    return   res.status(200).end('success');

});


function getRandomSalt() {
    var milliseconds = new Date().getTime();
    var timestamp = (milliseconds.toString()).substring(9, 13)
    var random = ("" + Math.random()).substring(2, 8);
    var random_number = timestamp+random;  // string will be unique because timestamp never repeat itself
    return random_number;
}

 



app.listen(2000, function (a) {
    console.log("Listening to port 2000");
});