$(document).on('keyup', '#editor1', function(){
  alert('keyup');
});

$('body').on('click','.plus-add-move-data-source-tab', function() {
    $('a[href="#data-source"]').tab('show');  
});

$("select.select-type-select").change(function(){
    var data = $(this).children("option:selected").val();
    if(data == 'Sub Clause'){
      $('.main-clause-select').css('display','block');
      $('.sub-clause-select').css('display','none');
      $('.sub-sub-clause').css('display','none');
    }else if(data == 'Sub Sub Clause'){
      $('.main-clause-select').css('display','block');
      $('.sub-clause-select').css('display','block');
      $('.sub-sub-clause').css('display','none');
    }else if(data == 'Sub Sub Sub Clause'){
      $('.main-clause-select').css('display','block');
      $('.sub-clause-select').css('display','block');
      $('.sub-sub-clause').css('display','block');
    }
    else{
      $('.main-clause-select').css('display','none');
      $('.sub-clause-select').css('display','none');
      $('.sub-sub-clause').css('display','none'); 
    }
});

$('.add-new-form').click(function(){
    var getBox = $('.append-div-box').html();
    $('.main-box-section').append(getBox);
});

$('.remove-new-form').click(function(){
    $('.main-box-section').find('li:last-child').remove();
});

$('body').on('click','.next-rule-engine-step-1', function () {
  var data = $('.select-type-tem-cla option:selected').val();
  if(data == 'template'){
    $('.second-tbl').css('display','block');
    $('.clause-tbl').css('display','none');
  }else if(data == 'clause'){
    $('.second-tbl').css('display','none');
    $('.clause-tbl').css('display','block');
  }else{
    $('.second-tbl').css('display','block');
    $('.clause-tbl').css('display','block');
  }
});

$(document).ready(function(){
$('body').on('change','.click-select', function () {
        var data = $(this).val();
        if(data == 'category'){
            $(this).parents('tr').find('td').find('.open-select').css('display','block');
            $(this).parents('tr').find('td').find('.open-input').css('display','none');
        }else if(data == 'url'){
            $(this).parents('tr').find('td').find('.open-select').css('display','none');
            $(this).parents('tr').find('td').find('.open-input').css('display','block');
        }else{
            $(this).parents('tr').find('td').find('.open-select').css('display','none');
            $(this).parents('tr').find('td').find('.open-input').css('display','none');

        }
    });
});

$('body').on('click', '.add-row-btn', function(){
    var addRow = $('.table-set-up-funnel tbody tr:last-child').html();
    var noRow = $(this).parents('.main-tbl').find('tbody tr:last-child th:first-child').html();
    var noRow1 = Number(noRow)+1;
    $(this).parents('.main-tbl').find('.table-set-up-funnel tbody').append('<tr class="new">'+addRow+'</tr>');
    $(this).parents('.main-tbl').find('.table-set-up-funnel tbody tr:last-child th').html(noRow1);
});

$('body').on('click', '.remove-row-btn', function(){
    var firstTr = $(this).parents('.main-tbl').find('tbody tr:last-child').attr('class');
    if(firstTr == 'new'){
        $(this).parents('.main-tbl').find('tbody tr:last-child').remove();
    }
});

$('.rule-engine-check-box-last-previous').click(function(){
  $('.rule-engine-step-2').css('display','block');
  $('.rule-engine-step-3').css('display','none');
});

$('.template-library-save-next').click(function(){
  $('.compose-clause-main-template').css('display','block');
  $('.createNewTempMain').css('display','none');
});

$('.next-rule-engine-step-1').click(function(){
  $('.rule-engine-step-2').css('display','block');
  $('.rule-engine-step-1').css('display','none');
});

$('.rule-engine-check-box-2-next').click(function(){
  $('.rule-engine-step-3').css('display','block');
  $('.rule-engine-step-2').css('display','none');
});

$('.rule-engine-check-box-2-previous').click(function(){
  $('.rule-engine-step-1').css('display','block');
  $('.rule-engine-step-2').css('display','none');
});

$('.next-dymanic-document-btn').click(function(){
  $('.template-engine-section').css('display','block');
  $('.content-document-main').css('display','none');
});

$('.approval-section-part-previous').click(function(){
  $('.template-engine-section').css('display','block');
  $('.approval-section-part').css('display','none');
});

$('.previous-dymanic-document-btn').click(function(){
  $('.template-engine-section').css('display','none');
  $('.content-document-main').css('display','block');
});

$('.next-template-engine-section').click(function(){
  $('.template-engine-section').css('display','none');
  $('.approval-section-part').css('display','block');
});

$('.select-qr-3').on('change', function() {
  var data = this.value;
  if(data == 'select-qr-3'){
    $('.field-select-qr-3').css('display','block');
  }else{
    $('.field-select-qr-3').css('display','none');
  }
});

$('.select-ob-3').on('change', function() {
  var data = this.value;
  if(data == 'select-ob-3'){
    $('.field-select-ob-3').css('display','block');
  }else{
    $('.field-select-ob-3').css('display','none');
  }
});

$('.select-ob-2').on('change', function() {
  var data = this.value;
  if(data == 'select-ob-2'){
    $('.select-fi-2').css('display','block');
  }else{
    $('.select-fi-2').css('display','none');
  }
});

$('.select-qr-2').on('change', function() {
  var data = this.value;
  if(data == 'select-ob-2'){
    $('.field-select-qr-2').css('display','block');
  }else{
    $('.field-select-qr-2').css('display','none');
  }
});

$('.select-ob-1').on('change', function() {
  var data = this.value;
  if(data == 'select-ob-1'){
    $('.select-fi-1').css('display','block');
  }else{
    $('.select-fi-1').css('display','none');
  }
});

$('.select-gr-1').on('change', function() {
  var data = this.value;
  if(data == 'select-ob-1'){
    $('.select-qr-1').css('display','block');
  }else{
    $('.select-qr-1').css('display','none');
  }
});

$('.check-box-next-step').click(function(){
  $('.compose-clause-main-section').css('display','block');
  $('.check-box-section-clause').css('display','none');
});

$('.compose-clause-previous-btn').click(function(){
  $('.compose-clause-main-section').css('display','none');
  $('.check-box-section-clause').css('display','block');
});

$('.check-box-previous-step').click(function(){
  $('.create-from-existing-manually').css('display','block');
  $('.check-box-section-clause').css('display','none');
});


$('.previous-text-next').click(function(){
  $('.check-box-section-clause').css('display','block');
  $('.create-from-existing-manually').css('display','none');
});

$('.create-new-clause-btn').click(function(){
  $('.table-clause-clause-main').css('display','none');
  $('.createNewClauseMain').css('display','block');
  $('.create-new-clause-btn').css('display','block');
});

$('.create-from-existing-documents-next').click(function(){
  var data = $(".create-from-existing-documents:checked").val();
  if(data == 'create-from-existing-documents'){
    $('.create-from-existing-documents').css('display','block');
    $('.createNewClauseMain').css('display','none');
  }
});

$('.create-from-existing-documents-previous').click(function(){
  $('.create-from-existing-documents').css('display','none');
  $('.createNewClauseMain').css('display','block');
});

$('.main-clause-library-previous').click(function(){
  $('.createNewClauseMain').css('display','none');
  $('.table-clause-clause-main').css('display','block');
  $('.create-new-clause-btn').css('display','block');
});

$('.previous-text-box').click(function(){
  $('.create-from-existing-manually').css('display','none');
  $('.createNewClauseMain').css('display','block');
});

$('.first-previous-clause').click(function(){
  $('.compose-clause-main-section').css('display','none');
  $('.createNewClauseMain').css('display','block');
});

$('.create-from-existing-documents-next').click(function(){
  var data = $(".enter-manually:checked").val();
  if(data == 'enter-manually'){
    $('.createNewClauseMain').css('display','none');
    $('.compose-clause-main-section').css('display','block');
    $('.tabcontent-btn-Forth').trigger('click');
  }
});

$('.create-from-existing-documents-next').click(function(){
  var data = $(".advanced-clauses-check:checked").val();
  if(data == 'advanced-clauses'){
    $('.enter-manually-radio').css('display','block');
  }else{
    $('.enter-manually-radio').css('display','none');
  }
});

$('.create-from-existing-documents-next').click(function(){
  var data = $(".advanced-clauses-check:checked").val();
  if(data == 'advanced-clauses'){
    $('.selected-feilds-text-area').css('display','block');
  }else{
    $('.selected-feilds-text-area').css('display','none');
  }
});

$(document).ready(function(){
  $('#drop-down-up-file-clauses').change(function(){
    $('.multipart-text-clauses').css('display','block');
    $('.drop-down-up-file-clauses').css('display','none');
  });
});

$('.sinatory').click(function(){
  var data = $(".sinatory:checked").val();
  if(data == 'sinatory'){
    $('.sinatory-input').css('display','block');
  }else{
    $('.sinatory-input').css('display','none');
  }
});

$('.approver').click(function(){
  var data = $(".approver:checked").val();
  if(data == 'approver'){
    $('.approver-input').css('display','block');
  }else{
    $('.approver-input').css('display','none');
  }
});

// $(document).ready(function(){
$('body').on('change','.file-open-one-one', function (e) {
  uploadFile();
});

$('.one-step-click').click(function(){
    $('.tabcontent-btn-menu-one').trigger('click');
});

$('.second-click').click(function(){
    $('.tabcontent-btn-second').trigger('click');
});

$('.third-panel').click(function(){
    $('.tabcontent-btn-third').trigger('click');
});

$('body').on('change','.file-open-second', function (e) {
    $('.editor-view-second').css('display','block');
    $('.drop-down-up-file-second').css('display','none');
    $('.tabcontent-btn-second').trigger('click');
});


function openPage(pageName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(pageName).style.display = "block";
  elmnt.style.backgroundColor = color;
}

function openPageSecond(pageName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(pageName).style.display = "block";
  elmnt.style.backgroundColor = color;
}

function openPageThird(pageName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(pageName).style.display = "block";
  elmnt.style.backgroundColor = color;
}

function openPageForth(pageName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(pageName).style.display = "block";
  elmnt.style.backgroundColor = color;
}

$(document).on('click', '.panel-heading span.clickable', function (e) {
    var $this = $(this);
    if (!$this.hasClass('panel-collapsed')) {
        $this.parents('.panel').find('.panel-body').slideUp();
        $this.addClass('panel-collapsed');
        $this.find('i').removeClass('glyphicon-minus').addClass('glyphicon-plus');
    } else {
        $this.parents('.panel').find('.panel-body').slideDown();
        $this.removeClass('panel-collapsed');
        $this.find('i').removeClass('glyphicon-plus').addClass('glyphicon-minus');
    }
});

$(document).on('click', '.panel div.clickable', function (e) {
    var $this = $(this);
    if (!$this.hasClass('panel-collapsed')) {
        $this.parents('.panel').find('.panel-body').slideUp();
        $this.addClass('panel-collapsed');
        $this.find('i').removeClass('glyphicon-minus').addClass('glyphicon-plus');
    } else {
        $this.parents('.panel').find('.panel-body').slideDown();
        $this.removeClass('panel-collapsed');
        $this.find('i').removeClass('glyphicon-plus').addClass('glyphicon-minus');
    }
});

$(document).ready(function () {
    $('.panel-heading span.clickable').click();
    $('.panel div.clickable').click();
});

$("body").on("click", ".my-button", function(){
  var newText = $(this).text();
  var start = $('.mytextarea').prop('selectionStart');
  var finish = $('.mytextarea').prop('selectionEnd');
  var allText = $('.mytextarea').val();
  var sel = allText.substring(start, finish);
  var newText=allText.substring(0, start)+newText+allText.substring(finish, allText.length);
  $('.mytextarea').val(newText);
  console.log(newText);
});

$("body").on("click", ".my-button2", function(){
  var newText = $(this).find('p').text();
  var start = $('.mytextarea').prop('selectionStart');
  var finish = $('.mytextarea').prop('selectionEnd');
  var allText = $('.mytextarea').val();
  var sel = allText.substring(start, finish);
  var newText=allText.substring(0, start)+newText+allText.substring(finish, allText.length);
  $('.mytextarea').val(newText);
  console.log(newText);
});

$("body").on("click", ".my-button-second2", function(){
  var newText = $(this).find('p').text();
  var start = $('.mytextarea-second').prop('selectionStart');
  var finish = $('.mytextarea-second').prop('selectionEnd');
  var allText = $('.mytextarea-second').val();
  var sel = allText.substring(start, finish);
  var newText=allText.substring(0, start)+newText+allText.substring(finish, allText.length);
  $('.mytextarea-second').val(newText);
  console.log(newText);
});

$("body").on("click", ".my-button-second", function(){
  var newText = $(this).text();
  var start = $('.mytextarea-second').prop('selectionStart');
  var finish = $('.mytextarea-second').prop('selectionEnd');
  var allText = $('.mytextarea-second').val();
  var sel = allText.substring(start, finish);
  var newText=allText.substring(0, start)+newText+allText.substring(finish, allText.length);
  $('.mytextarea-second').val(newText);
  console.log(newText);
});

$("body").on("click", ".my-button-third", function(){
  var newText = $(this).text();
  var start = $('mytextarea-third').prop('selectionStart');
  var finish = $('mytextarea-third').prop('selectionEnd');
  var allText = $('mytextarea-third').val();
  var sel = allText.substring(start, finish);
  var newText=allText.substring(0, start)+newText+allText.substring(finish, allText.length);
  $('mytextarea-third').val(newText);
  console.log(newText);
});

$("body").on("click", ".dropdown-toggle", function(){
	var Sheight = $(this).parent('.bootstrap-select').find('.dropdown-menu.open').height();
	Sheight = Sheight;
	$('.tab-content').css('padding-bottom',Sheight);
});

$('.addAppWorkflow').click(function () {
 	var $this = $(this);
 	if ($this.is(':checked')) {
     	$('.addMoreTextboxMain').css('display','block');
 	} else {
     	$('.addMoreTextboxMain').css('display','none');
 	}
});

$('.add-more-btn-b').click(function(){
	var copy = $(this).parents('.addMore-b').find('.addMore-copy-b').html();
	$(this).parents('.addMore-b').find('.addMore-main-b').find('.addMoreNew').append(copy);
});



var ii = 1;
$('.add-more-btn-b-file').click(function(){
	var copy = $(this).parents('.addMore').find('.addMore-copy').html();
	copy = copy.replace("**1**",ii);
	copy = copy.replace("**1**",ii);
	ii++;
	$(this).parents('.addMore').find('.addMore-main').append(copy);
});

$('body').on('click', '.copy-remove-btn-b', function() { 
	$(this).parents('.addMore-sub-b').remove();
});

$('.cal-main .plus').click(function(){
	var copy = $(this).parents('.cal-main').find('.copy-cal').html();
	$(this).parents('.cal-main').find('.cal-sub').append(copy);

	$('.selectpicker').selectpicker('refresh');
	$(this).parents('.cal-main').find('.cal-sub').find(".custom-cal-sub:last").find(".bs-placeholder:first").css("display","none");
	$(this).parents('.cal-main').find('.cal-sub').find(".custom-cal-sub:last").find(".sf-remove").find(".bs-placeholder:first").css("display","none");
});

$('.cal-main .minus').click(function(){
	var first = $(this).parents('.cal-main').find('.cal-sub .row:last-child').attr('data-class');
	if(first != 'first'){
		$(this).parents('.cal-main').find('.cal-sub .row:last-child').remove();
	}
});

$('body').on('click', '.add-more-btn', function() { 
	var copy = $(this).parents('.addMore').find('.addMore-copy').html();
	$(this).parents('.addMore').find('.addMore-main').append(copy);
	$('.selectpicker').selectpicker('refresh');
	$(this).parents('.addMore').find('.addMore-sub:last-child').find(".dropdown-toggle:first").css("display","none");
	$(this).parents('.addMore').find('.addMore-sub:last-child').find('.form-group').find(".dropdown-toggle:first").css("display","none");
});

$('body').on('click', '.add-more-btn-p', function() { 
  var copy = $(this).parents('.addMore-p').find('.addMore-copy-p').html();
  $(this).parents('.addMore-p').find('.addMore-main-p').append(copy);
  $('.selectpicker').selectpicker('refresh');
  $(this).parents('.addMore-p').find('.addMore-sub-p:last-child').find(".dropdown-toggle:first").css("display","none");
  $(this).parents('.addMore-p').find('.addMore-sub-p:last-child').find('.form-group').find(".dropdown-toggle:first").css("display","none");
});

$('body').on('click', '.add-more-btn-p', function() { 
  var a1 = $(this).parents('.addMore-p').find('.addMore-sub-p:last-child .compose_online').attr('id');
  var b1 = Number(a1.substring(13)) + Number(1);
  var idc1 = 'composeOnline'+b1;

  $(this).parents('.addMore-p').find('.addMore-sub-p:last-child .compose_online').attr('id', idc1);
  $(this).parents('.addMore-p').find('.addMore-sub-p:last-child .compose_online_for').attr('for', idc1);

  var a2 = $(this).parents('.addMore-p').find('.addMore-sub-p:last-child .upload_file').attr('id');
  var b2 = Number(a2.substring(10)) + Number(1);
  var idc2 = 'uploadFile'+b2;

  $(this).parents('.addMore-p').find('.addMore-sub-p:last-child .upload_file').attr('id', idc2);
  $(this).parents('.addMore-p').find('.addMore-sub-p:last-child .upload_file_for').attr('for', idc2);

  var a3 = $(this).parents('.addMore-p').find('.addMore-sub-p:last-child .upload_file').attr('id');
  var b3 = Number(a2.substring(10)) + Number(1);
  var name = 'radio-group'+b3;

  $(this).parents('.addMore-p').find('.addMore-sub-p:last-child .compose_online').attr('name', name);
  $(this).parents('.addMore-p').find('.addMore-sub-p:last-child .upload_file').attr('name', name);
});

// advance radio button

$('body').on('click', '.add-more-btn-np', function() { 
  var copy = $(this).parents('.addMore-np').find('.addMore-copy-np').html();
  $(this).parents('.addMore-np').find('.addMore-main-np').append(copy);
  $('.selectpicker').selectpicker('refresh');
  $(this).parents('.addMore-np').find('.addMore-sub-np:last-child').find(".dropdown-toggle:first").css("display","none");
  $(this).parents('.addMore-np').find('.addMore-sub-np:last-child').find('.form-group').find(".dropdown-toggle:first").css("display","none");
});

$('body').on('click', '.add-more-btn-np', function() {
  var a1 = $(this).parents('.addMore-np').find('.addMore-sub-np:last-child .compose_online').attr('id');
  var b1 = Number(a1.substring(13)) + Number(1);
  var idc1 = 'ComposeOnline'+b1;

  $(this).parents('.addMore-np').find('.addMore-sub-np:last-child .compose_online').attr('id', idc1);
  $(this).parents('.addMore-np').find('.addMore-sub-np:last-child .compose_online_for').attr('for', idc1);

  var a2 = $(this).parents('.addMore-np').find('.addMore-sub-np:last-child .upload_file').attr('id');
  var b2 = Number(a2.substring(10)) + Number(1);
  var idc2 = 'UploadFile'+b2;

  $(this).parents('.addMore-np').find('.addMore-sub-np:last-child .upload_file').attr('id', idc2);
  $(this).parents('.addMore-np').find('.addMore-sub-np:last-child .upload_file_for').attr('for', idc2);

  var a3 = $(this).parents('.addMore-np').find('.addMore-sub-np:last-child .upload_file').attr('id');
  var b3 = Number(a3.substring(10)) + Number(1);
  var name = 'radio-Group'+b3;

  $(this).parents('.addMore-np').find('.addMore-sub-np:last-child .compose_online').attr('name', name);
  $(this).parents('.addMore-np').find('.addMore-sub-np:last-child .upload_file').attr('name', name);
});

$('body').on('click', '.copy-remove-btn', function() { 
  $(this).parents('.addMore-sub').remove();
});

$('.create-new-clause-btn').click(function (e) {
    e.preventDefault();
    $('.create-new-clause-btn').css('display','none');
    $('.createNewClauseMain').css('display','block');
    $('.table-clause-library').css('display','none');
    $('.compose-clause-main').css('display','none');
    $('.select-sfdc-object-main').css('display','none');
    $('.external-parameter-main').css('display','none');
});


$('.clause-library-save-next').click(function () {
    $('.createNewClauseMain').css('display','none');
    $('.select-sfdc-object-main').css('display','block');
});

$('body').on('click', '.upload_file', function() { 
  var $this = $(this);
  if ($this.is(':checked')) {
      $(this).parents('.addMore-sub-p').find('.addMore-b').find('.upload-file-main').css('display','block');
      $(this).parents('.addMore-sub-p').find('.addMore-b').find('.compose-online-main').css('display','none');
  }
});

$('body').on('click', '.upload_file', function() { 
  var $this = $(this);
  if ($this.is(':checked')) {
      $(this).parents('.addMore-sub-np').find('.addMore-b').find('.upload-file-main').css('display','block');
      $(this).parents('.addMore-sub-np').find('.addMore-b').find('.compose-online-main').css('display','none');
  }
});

$('body').on('click', '.compose_online', function() { 
  var $this = $(this);
  if ($this.is(':checked')) {
      $(this).parents('.addMore-sub-np').find('.addMore-b').find('.compose-online-main').css('display','block');
      $(this).parents('.addMore-sub-np').find('.addMore-b').find('.upload-file-main').css('display','none');
  }
});

$('body').on('click', '.compose_online', function() { 
 	var $this = $(this);
 	if ($this.is(':checked')) {
     	$(this).parents('.addMore-sub-p').find('.addMore-b').find('.compose-online-main').css('display','block');
     	$(this).parents('.addMore-sub-p').find('.addMore-b').find('.upload-file-main').css('display','none');
 	}
});
// $('.upload_file1').click(function () {
//  	var $this = $(this);
//  	if ($this.is(':checked')) {
//      	$('.upload-file-main1').css('display','block');
//      	$('.compose-online-main1').css('display','none');
//  	}
// });
// $('.compose_online1').click(function () {
//  	var $this = $(this);
//  	if ($this.is(':checked')) {
//      	$('.compose-online-main1').css('display','block');
//      	$('.upload-file-main1').css('display','none');
//  	}
// });

$('.advanced').click(function () {
 	var $this = $(this);
 	if ($this.is(':checked')) {
     	$('.advanced-main').css('display','block');
 	} else {
     	$('.advanced-main').css('display','none');
 	}

 	if ($this.is(':checked')) {
 		if ($('#rules-based').is(':checked')) {
     		$('.select-rule-clause-lib').css('display','block');
 		}
 	} else {
     	$('.select-rule-clause-lib').css('display','none');
 	}
});

$('.advanced-dynamic-doc').click(function () {
 	var $this = $(this);
 	if ($this.is(':checked')) {
     	$('.dynamic-doc-controle-name-main').css('display','block');
 	} else {
     	$('.dynamic-doc-controle-name-main').css('display','none');
 	}
});

$('.clause-library-add-new').click(function () {
		$( ".wizard-navigation ul li a.tab-workflow" ).trigger( "click" );
});


// $(document).ready(function(){
//   $('#file-open-third').change(function(){
//     $('#drop-down-up-file-third').css('display','none');
//     $('#editor-view-third').css('display','block');
//     $('.ck-editor-text').css('display','block');
//   });
// });


// $(document).ready(function(){
//     $(".control-input").click(function(){
//       var radioValue = $("input[name='up-tem']:checked").val();
//         if(radioValue == 'existing-document'){
//           $('.drop-down-up-file').css('display','block');
//         }
//         if(radioValue == 'up-template' || radioValue == 'existing-document' || radioValue == 'up-document-editor' || radioValue == 'doctiger-gallary' ){
//           $('input[type="file"]').val('');
//         }
//     });
// });

// $(document).ready(function(){
//     $('input[type="file"]').change(function(){
//       var data = $('.control-input:checked').val();
//       if(data == 'existing-document'){
//         $('.editor-view').css('display','block');
//         $('.ck-editor-text').css('display','none');
//         $('.drop-down-up-file').css('display','none');
//       }
//     });
// });

// $(document).ready(function(){
//     $(".control-input").click(function(){
//       var radioValue = $("input[name='up-tem']:checked").val();
//         if(radioValue == 'up-template'){
//           $('.drop-down-up-file').css('display','block');
//           $('.editor-view').css('display','none');
//         }
//     });
// });

// $(document).ready(function(){
//     $('input[type="file"]').change(function(){
//       var data = $('.control-input:checked').val();
//       if(data == 'up-template'){
//         $('.editor-view').css('display','block');
//         $('.drop-down-up-file').css('display','none');
//       }
//     });
// });

// $(document).ready(function(){
//     $(".control-input").click(function(){
//       var radioValue = $("input[name='up-tem']:checked").val();
//         if(radioValue == 'up-document-editor'){
//           $('.drop-down-up-file').css('display','block');
//           $('.ck-editor-text').css('display','none');
//           $('.editor-view').css('display','none');
//         }
//     });
// });

// $(document).ready(function(){
//     $('input[type="file"]').change(function(){
//       var data = $('.control-input:checked').val();
//       if(data == 'up-document-editor'){
//         $('.editor-view').css('display','block');
//         $('.ck-editor-text').css('display','block');
//         $('.drop-down-up-file').css('display','none');
//       }
//     });
// });

// $(document).ready(function(){
//     $(".control-input").click(function(){
//       var radioValue = $("input[name='up-tem']:checked").val();
//         if(radioValue == 'doctiger-gallary'){
//           $('.drop-down-up-file').css('display','block');
//           $('.editor-view').css('display','none');
//         }
//     });
// });

// $(document).ready(function(){
//     $('input[type="file"]').change(function(){
//       var data = $('.control-input:checked').val();
//       if(data == 'doctiger-gallary'){
//         $('.editor-view').css('display','block');
//         $('.ck-editor-text').css('display','none');
//         $('.drop-down-up-file').css('display','none');
//       }
//     });
// });

// $(document).ready(function(){
//     $('input[type="file"]').change(function(){
//       var data = $('.control-input:checked').val();
//       if(data == 'up-template'){
//         $('.drop-down-up-file').css('display','block');
//         $('.editor-view').css('display','none');
//       }
//     });
// });

$('.editor-view-right ul li a').click(function() {
    $('.editor-view-right ul li a').removeClass('active');
    $(this).addClass('active');
});

$("body").on("change", "#selectEvent-communication", function(){
  	var option = $(this).val();
  	
  	if(option == "eventnew"){
  		$('#communication .eventold').css('display','none');
  		$('#communication .eventnew').css('display','block');
  	}else{
  		$('#communication .eventnew').css('display','none');
  		$('#communication .eventold').css('display','block');
  	}
  	
});

$("body").on("change", ".eventnew .schedule_push", function(){
	var val = $(this).attr('value');

	if(val == "push"){
		$('.schedule_push_hideShow').css('display','none');
	}else{
		$('.schedule_push_hideShow').css('display','block');
	}
});

$('.comunication-sectioin-main-last .plus').click(function(){
	var copy = $(this).parents('.comunication-sectioin-main-last').find('.comunication-sectioin-main-copy-sub').html();
	$(this).parents('.comunication-sectioin-main-last').find('.comunication-sectioin-main-last-sub').append(copy);
	$('.selectpicker').selectpicker('refresh');
	$(this).parents('.comunication-sectioin-main-last').find('.comunication-sectioin-main-last-sub').find('.row:last').find('.form-group').find(".dropdown-toggle:first").css("display","none");
});

$('.comunication-sectioin-main-last .minus').click(function(){
	var first = $(this).parents('.comunication-sectioin-main-last').find('.comunication-sectioin-main-last-sub .row:last-child').attr('data-class');
	if(first != 'first'){
		$(this).parents('.comunication-sectioin-main-last').find('.comunication-sectioin-main-last-sub .row:last-child').remove();
	}
});

$('.create-new-template-btn').click(function (e) {
    e.preventDefault();
    $('.create-new-template-btn').css('display','none');
    $('.createNewTempMain').css('display','block');
    $('.table-clause-template').css('display','none');
    // $('.compose-clause-main-template').css('display','none');
    $('.select-sfdc-object-main-template').css('display','none');
    $('.external-parameter-main-template').css('display','none');
});

$('.check-box-section-previous-btn').click(function () {
    $('.check-box-section').css('display','none');
    $('.createNewTempMain').css('display','block');
});

$('.mail-template-sfdc-previous-btn').click(function () {
    $('.select-sfdc-object-main-template').css('display','none');
    $('.check-box-section').css('display','block');
});

$('.template-library-save-next').click(function () {
    $('.createNewTempMain').css('display','none');
    // $('.compose-clause-main-template').css('display','block');
});

$('.check-box-section-next').click(function () {
    $('.check-box-section').css('display','none');
    // $('.compose-clause-main-template').css('display','block');
});

$('.compose-clause-temp-lib-pre-btn').click(function () {
    $('.createNewTempMain').css('display','block');
    // $('.compose-clause-main-template').css('display','none');
});


$(document).ready(function(){
    $(".custom-control-input").click(function(){
      var radioValue = $("input[name='type_radio']:checked").val();
        if(radioValue == 0){
          $('.check-radio-op-one').css('display','block');
        }
        else{
          $('.check-radio-op-one').css('display','none');
        }
    });
});

// $(document).ready(function(){
//     $(".control-input").click(function(){
//       var radioValue = $("input[name='up-tem']:checked").val();
//         if(radioValue == 'existing-document'){
//           $('.drop-down-up-file').css('display','block');
//         }else if(radioValue == 'up-template'){
//           $('.drop-down-up-file').css('display','block');
//         }else{
//           $('.drop-down-up-file').css('display','block');
//         }
//     });
// });

$(document).ready(function(){
    $(".custom-control-input").click(function(){
      var radioValue = $("input[name='type_radio']:checked").val();
        if(radioValue == 1){
          $('.check-radio-op-second').css('display','block');
        }
        else{
          $('.check-radio-op-second').css('display','none');
        }
    });
});
$(document).ready(function(){
    $(".custom-control-input").click(function(){
      var radioValue = $("input[name='type_radio']:checked").val();
        if(radioValue == 2){
          $('.check-radio-op-third').css('display','block');
        }
        else{
          $('.check-radio-op-third').css('display','none');
        }
    });
});

$('.create-new-mail-template-btn').click(function (e) {
    e.preventDefault();
    $('.create-new-mail-template-btn').css('display','none');
    $('.createNewMailTempMain').css('display','block');
    $('.table-mail-template').css('display','none');
    $('.compose-clause-mail-temp-main').css('display','none');
    $('.select-sfdc-object-mail-temp-main').css('display','none');
    $('.external-parameter-mail-temp-main').css('display','none');
});

$('.mail-template-save-next').click(function () {
    $('.createNewMailTempMain').css('display','none');
    $('.external-parameter-mail-temp-main').css('display','block');
});

$('.document-next-btn').click(function () {
    $('.content-document-main').css('display','none');
    $('.content-document-main2').css('display','block');
});

$('.upload_file_mail_temp').click(function () {
 	var $this = $(this);
 	if ($this.is(':checked')) {
     	$('.upload-file-mail-temp-main').css('display','block');
     	$('.compose-online-mail-temp-main').css('display','none');
 	}
});

$('.compose_online_mail_temp').click(function () {
 	var $this = $(this);
 	if ($this.is(':checked')) {
     	$('.compose-online-mail-temp-main').css('display','block');
     	$('.upload-file-mail-temp-main').css('display','none');
 	}
});

$('.advanced_mail_temp').click(function () {
 	var $this = $(this);
 	if ($this.is(':checked')) {
    	$('.advanced-mail-temp-main').css('display','block');
 	} else {
     	$('.advanced-mail-temp-main').css('display','none');
 	}
});

$('.cls-lib-sfdc-save-next').click(function () {
    $('.select-sfdc-object-main').css('display','none');
 	if ($('#external-parameter').is(':checked')) {
     	$('.external-parameter-main').css('display','block');
     	$('.compose-clause-main').css('display','none');
 	} else {
     	$('.compose-clause-main').css('display','block');
     	$('.external-parameter-main').css('display','none');
 	}
});


$('.cls-lib-external-para-save-next').click(function () {
    $('.external-parameter-main').css('display','none');
    $('.compose-clause-main').css('display','block');
});

$('#rules-based').click(function () {
 	var $this = $(this);
 	if ($this.is(':checked')) {
 		if($('.advanced').is(':checked')){
     		$('.select-rule-clause-lib').css('display','block');
 		}
 	} else {
     	$('.select-rule-clause-lib').css('display','none');
 	}
});

$('#approval-workflow').click(function () {
 	var $this = $(this);
 	if ($this.is(':checked')) {
     	$('.select-workflow-clause-lib').css('display','block');
 	} else {
     	$('.select-workflow-clause-lib').css('display','none');
 	}
});

$('.compose-clause-save-btn').click(function () {
    $('.createNewClauseMain').css('display','none');
    $('.select-sfdc-object-main').css('display','none');
    $('.external-parameter-main').css('display','none');
    $('.compose-clause-main').css('display','none');
    $('.table-clause-library').show();
    $('.table-clause-library-main').css('display','block');
    $('.create-new-clause-btn').css('display','block');
});

$('.mail-template-sfdc-save-next').click(function () {
    $('.select-sfdc-object-main-template').css('display','none');
 	if ($('#check-external-parameter-temp').is(':checked')) {
     	$('.external-parameter-main-template').css('display','block');
     	$('.compose-clause-main-template').css('display','none');
 	} else {
     	$('.compose-clause-main-template').css('display','block');
     	$('.external-parameter-main-template').css('display','none');
 	}
});

$('.temp-external-para-save-next').click(function () {
    $('.external-parameter-main-template').css('display','none');
    $('.compose-clause-main-template').css('display','block');
});

$('#dynamic').click(function () {
 	var $this = $(this);
 	if ($this.is(':checked')) {
     	$('.select-dynamic-main-temp-lib').css('display','block');
 	} else {
     	$('.select-dynamic-main-temp-lib').css('display','none');
 	}
});

$('#workflow-template').click(function () {
 	var $this = $(this);
 	if ($this.is(':checked')) {
     	$('.select-workflow-main-temp').css('display','block');
 	} else {
     	$('.select-workflow-main-temp').css('display','none');
 	}
});

$('.compose-clause-temp-lib-save-btn').click(function () {
    $('.createNewTempMain').css('display','none');
    $('.select-sfdc-object-main-template').css('display','none');
    $('.external-parameter-main-template').css('display','none');
    $('.compose-clause-main-template').css('display','none');
    $('.table-clause-template').show();
    $('.table-clause-template-main').css('display','block');
});

$('.mail-temp-sfdc-save-next').click(function () {
    $('.select-sfdc-object-mail-temp-main').css('display','none');
 	if ($('#external-parameter-mail-temp').is(':checked')) {
     	$('.external-parameter-mail-temp-main').css('display','block');
     	$('.compose-clause-mail-temp-main').css('display','none');
 	} else {
     	$('.compose-clause-mail-temp-main').css('display','block');
     	$('.external-parameter-mail-temp-main').css('display','none');
 	}
});

$('.mail-temp-external-save-next').click(function () {
    $('.external-parameter-mail-temp-main').css('display','none');
    $('.compose-clause-mail-temp-main').css('display','block');
});

$('#rules-based-mail-temp').click(function () {
 	var $this = $(this);
 	if ($this.is(':checked')) {
     	$('.select-rule-mail-temp').css('display','block');
 	} else {
     	$('.select-rule-mail-temp').css('display','none');
 	}
});

$('#workflow-template-mail').click(function () {
 	var $this = $(this);
 	if ($this.is(':checked')) {
     	$('.select-workflow-mail-temp').css('display','block');
 	} else {
     	$('.select-workflow-mail-temp').css('display','none');
 	}
});

$('.mail-temp-compose-save-btn').click(function () {
    $('.createNewMailTempMain').css('display','none');
    $('.select-sfdc-object-mail-temp-main').css('display','none');
    $('.external-parameter-mail-temp-main').css('display','none');
    $('.compose-clause-mail-temp-main').css('display','none');
    $('.table-mail-template').show();
    $('.table-mail-template-main').css('display','block');
});

$("body").on("change", ".change-attach", function(){
  	var option = $(this).val();

  	if(option == "Select Controller"){
  		$(this).parents('.comunication-sectioin-last').find('.controller-textbox').css('display','block');
  		$(this).parents('.comunication-sectioin-last').find('.file-path-textbox').css('display','none');
  	}else if(option == "Select File Path"){
  		$(this).parents('.comunication-sectioin-last').find('.file-path-textbox').css('display','block');
  		$(this).parents('.comunication-sectioin-last').find('.controller-textbox').css('display','none');
  	}else if(option == "Select Attachment" || option == "Template1" || option == "Template2"){
  		$(this).parents('.comunication-sectioin-last').find('.file-path-textbox').css('display','none');		
  		$(this).parents('.comunication-sectioin-last').find('.controller-textbox').css('display','none');		
  	}
});


var items = {'Account':['AccountId', 'AccountName'], 'Case':['CaseId', 'CaseSubject'], 'Lead':['LeadId','LeadName'], 'Oppurtunity':['OppurtunityId', 'OppurtunityName']};

// Clause library tab sf-object
$("body").on("change", ".sf-object", function(){
var heading = $(this).val();
console.log(heading);
if($(".box-left").find('h3[data-name="'+heading+'"]').text() == ''){
    $(".box-left").append('<div class="list-part"><h3 data-name="'+heading+'">'+heading+'</h3><ul><li>'+items[heading]['0']+'</li><li>'+items[heading]['1']+'</li></ul></div>');
}
console.log(items[heading]);
});

$("body").on("click", ".click-right", function(){
 $(".box li.selected").each(function() {
    var heading = $(this).parent("ul").parent("div").find("h3").text();
    var liText = $(this).text();

      if($(".box-right").find('h3[data-name="'+heading+'"]').text() != ''){
        $(".box-right").find('h3[data-name="'+heading+'"]').parent("div").find("ul").append("<li>"+liText+"</li>");
      }else{
        $(".box-right").append('<div class="list-part"><h3 data-name="'+heading+'">'+heading+'</h3><ul><li>'+liText+'</li></ul></div>');
      }

      if ($(this).parent("ul").parent("div").find("ul li").length == 1) {
          $(this).parent("ul").parent("div").remove();
      }else{
        $(this).remove();
      }
  });
});

$("body").on("click", ".click-left", function(){
 $(".box li.selected").each(function() {
    var heading = $(this).parent("ul").parent("div").find("h3").text();
    var liText = $(this).text();

      if($(".box-left").find('h3[data-name="'+heading+'"]').text() != ''){
        $(".box-left").find('h3[data-name="'+heading+'"]').parent("div").find("ul").append("<li>"+liText+"</li>");
      }else{
        $(".box-left").append('<div class="list-part"><h3 data-name="'+heading+'">'+heading+'</h3><ul><li>'+liText+'</li></ul></div>');
      }

      if ($(this).parent("ul").parent("div").find("ul li").length == 1) {
          $(this).parent("ul").parent("div").remove();
      }else{
        $(this).remove();
      }
  });
});

// Template library tab sf-object
$("body").on("change", ".sf-object-temp-lib", function(){
var heading = $(this).val();
console.log(heading);
if($(".box-left-temp-lib").find('h3[data-name="'+heading+'"]').text() == ''){
    $(".box-left-temp-lib").append('<div class="list-part"><h3 data-name="'+heading+'">'+heading+'</h3><ul><li>'+items[heading]['0']+'</li><li>'+items[heading]['1']+'</li></ul></div>');
}
console.log(items[heading]);
});

$("body").on("click", ".click-right-temp-lib", function(){
 $(".box li.selected").each(function() {
    var heading = $(this).parent("ul").parent("div").find("h3").text();
    var liText = $(this).text();

      if($(".box-right-temp-lib").find('h3[data-name="'+heading+'"]').text() != ''){
        $(".box-right-temp-lib").find('h3[data-name="'+heading+'"]').parent("div").find("ul").append("<li>"+liText+"</li>");
      }else{
        $(".box-right-temp-lib").append('<div class="list-part"><h3 data-name="'+heading+'">'+heading+'</h3><ul><li>'+liText+'</li></ul></div>');
      }

      if ($(this).parent("ul").parent("div").find("ul li").length == 1) {
          $(this).parent("ul").parent("div").remove();
      }else{
        $(this).remove();
      }
  });
});

$("body").on("click", ".click-left-temp-lib", function(){
 $(".box li.selected").each(function() {
    var heading = $(this).parent("ul").parent("div").find("h3").text();
    var liText = $(this).text();

      if($(".box-left-temp-lib").find('h3[data-name="'+heading+'"]').text() != ''){
        $(".box-left-temp-lib").find('h3[data-name="'+heading+'"]').parent("div").find("ul").append("<li>"+liText+"</li>");
      }else{
        $(".box-left-temp-lib").append('<div class="list-part"><h3 data-name="'+heading+'">'+heading+'</h3><ul><li>'+liText+'</li></ul></div>');
      }

      if ($(this).parent("ul").parent("div").find("ul li").length == 1) {
          $(this).parent("ul").parent("div").remove();
      }else{
        $(this).remove();
      }
  });
});

// System > mail template tab sf-object
$("body").on("change", ".sf-object-mail-temp", function(){
var heading = $(this).val();
console.log(heading);
if($(".box-left-mail-temp").find('h3[data-name="'+heading+'"]').text() == ''){
    $(".box-left-mail-temp").append('<div class="list-part"><h3 data-name="'+heading+'">'+heading+'</h3><ul><li>'+items[heading]['0']+'</li><li>'+items[heading]['1']+'</li></ul></div>');
}
console.log(items[heading]);
});

$("body").on("click", ".click-right-mail-temp", function(){
 $(".box li.selected").each(function() {
    var heading = $(this).parent("ul").parent("div").find("h3").text();
    var liText = $(this).text();

      if($(".box-right-mail-temp").find('h3[data-name="'+heading+'"]').text() != ''){
        $(".box-right-mail-temp").find('h3[data-name="'+heading+'"]').parent("div").find("ul").append("<li>"+liText+"</li>");
      }else{
        $(".box-right-mail-temp").append('<div class="list-part"><h3 data-name="'+heading+'">'+heading+'</h3><ul><li>'+liText+'</li></ul></div>');
      }

      if ($(this).parent("ul").parent("div").find("ul li").length == 1) {
          $(this).parent("ul").parent("div").remove();
      }else{
        $(this).remove();
      }
  });
});

$("body").on("click", ".click-left-mail-temp", function(){
$(".box li.selected").each(function() {
var heading = $(this).parent("ul").parent("div").find("h3").text();
var liText = $(this).text();

  if($(".box-left-mail-temp").find('h3[data-name="'+heading+'"]').text() != ''){
    $(".box-left-mail-temp").find('h3[data-name="'+heading+'"]').parent("div").find("ul").append("<li>"+liText+"</li>");
  }else{
    $(".box-left-mail-temp").append('<div class="list-part"><h3 data-name="'+heading+'">'+heading+'</h3><ul><li>'+liText+'</li></ul></div>');
  }

  if ($(this).parent("ul").parent("div").find("ul li").length == 1) {
      $(this).parent("ul").parent("div").remove();
  }else{
    $(this).remove();
  }
});
});

$("body").on("click", ".box li", function(){
$(this).toggleClass('selected');
});


// var input = document.getElementById( 'file-upload' );
// var infoArea = document.getElementById( 'file-upload-filename' );

// input.addEventListener( 'change', showFileName );

// function showFileName( event ) {
// var input = event.srcElement;
// var fileName = input.files[0].name;
// infoArea.textContent = fileName;
// }

$("body").on("change", ".test-xls",function(){
var fileName = $(this).val();
var cleanName=fileName.split('\\').pop();
$(this).parent("div").find(".test-xls-filename").text(cleanName);
console.log(cleanName);
});

$('.web-services-add').click(function(){
  $('.web-services').toggleClass('display-block','display-none');

  var webUrl = document.getElementById("web-services-url").value;
  var uploadXls = document.getElementById("upload-xls").files.length;

  if(webUrl != ''){
      var a = '';
          a = a+'<div class="row form-group">';
              a = a+'<div class="col-sm-3">';
                  a = a+'<input type="text" class="form-control" value="'+webUrl+'" placeholder="URL Name">';
              a = a+'</div>';
              a = a+'<div class="col-sm-3">';
                  a = a+'<button class="btn btn-warning sm-btn-custom"><i class="fa fa-edit"></i></button> ';
                  a = a+'<button class="btn btn-danger sm-btn-custom"><i class="fa fa-trash"></i></button>';
              a = a+'</div>';
          a = a+'</div>';

      $('.add-url-name-main').append(a);
      $('.web-services input').val('');
      $('.web-services select').val('');
  }

  if(uploadXls != '0'){
      var a = '';
          a = a+'<div class="row form-group">';
              a = a+'<div class="col-sm-3">';
                  a = a+'<input type="text" class="form-control" value="URL Name" placeholder="URL Name">';
              a = a+'</div>';
              a = a+'<div class="col-sm-3">';
                  a = a+'<button class="btn btn-warning sm-btn-custom"><i class="fa fa-edit"></i></button> ';
                  a = a+'<button class="btn btn-danger sm-btn-custom"><i class="fa fa-trash"></i></button>';
              a = a+'</div>';
          a = a+'</div>';

      $('.add-url-name-main').append(a);
      $('.web-services input').val('');
      $('.web-services select').val('');
      $('.web-services select').val('');
      document.getElementById("upload-xls").value = "";
      $("#upload-xls-filename").text('File Name');
  }
});

$('.web-services-add-temp-lib').click(function(){
  $('.web-services-temp-lib').toggleClass('display-block','display-none');

var webUrl = document.getElementById("web-services-url-temp-lib").value;
var uploadXls = document.getElementById("upload-xls-temp-lib").files.length;

if(webUrl != ''){
    var a = '';
        a = a+'<div class="row form-group">';
            a = a+'<div class="col-sm-3">';
                a = a+'<input type="text" class="form-control" value="'+webUrl+'" placeholder="URL Name">';
            a = a+'</div>';
            a = a+'<div class="col-sm-3">';
                a = a+'<button class="btn btn-warning sm-btn-custom"><i class="fa fa-edit"></i></button> ';
                a = a+'<button class="btn btn-danger sm-btn-custom"><i class="fa fa-trash"></i></button>';
            a = a+'</div>';
        a = a+'</div>';

    $('.add-url-name-main-temp-lib').append(a);
    $('.web-services-add-temp-lib input').val('');
    $('.web-services-add-temp-lib select').val('');
}

if(uploadXls != '0'){
    var a = '';
        a = a+'<div class="row form-group">';
            a = a+'<div class="col-sm-3">';
                a = a+'<input type="text" class="form-control" value="URL Name" placeholder="URL Name">';
            a = a+'</div>';
            a = a+'<div class="col-sm-3">';
                a = a+'<button class="btn btn-warning sm-btn-custom"><i class="fa fa-edit"></i></button> ';
                a = a+'<button class="btn btn-danger sm-btn-custom"><i class="fa fa-trash"></i></button>';
            a = a+'</div>';
        a = a+'</div>';

    $('.add-url-name-main-temp-lib').append(a);
    $('.web-services-add-temp-lib input').val('');
    $('.web-services-add-temp-lib select').val('');
    $('.web-services-add-temp-lib select').val('');
    document.getElementById("upload-xls-temp-lib").value = "";
    $("#upload-xls-filename-temp-lib").text('File Name');
}
});

var input3 = document.getElementById( 'upload-xls-temp-lib' );
var infoArea3 = document.getElementById( 'upload-xls-filename-temp-lib' );

input3.addEventListener( 'change', showFileName3 );

function showFileName3( event ) {
var input3 = event.srcElement;
var fileName3 = input3.files[0].name;
infoArea3.textContent = fileName3;
}

$('.web-services-add-mail-temp').click(function(){
  $('.web-services-mail-temp').toggleClass('display-block','display-none');

var webUrl = document.getElementById("web-services-url-mail-temp").value;
var uploadXls = document.getElementById("upload-xls-mail-temp").files.length;

if(webUrl != ''){
    var a = '';
        a = a+'<div class="row form-group">';
            a = a+'<div class="col-sm-3">';
                a = a+'<input type="text" class="form-control" value="'+webUrl+'" placeholder="URL Name">';
            a = a+'</div>';
            a = a+'<div class="col-sm-3">';
                a = a+'<button class="btn btn-warning sm-btn-custom"><i class="fa fa-edit"></i></button> ';
                a = a+'<button class="btn btn-danger sm-btn-custom"><i class="fa fa-trash"></i></button>';
            a = a+'</div>';
        a = a+'</div>';

    $('.add-url-name-main-mail-temp').append(a);
    $('.web-services-add-mail-temp input').val('');
    $('.web-services-add-mail-temp select').val('');
}

if(uploadXls != '0'){
    var a = '';
        a = a+'<div class="row form-group">';
            a = a+'<div class="col-sm-3">';
                a = a+'<input type="text" class="form-control" value="URL Name" placeholder="URL Name">';
            a = a+'</div>';
            a = a+'<div class="col-sm-3">';
                a = a+'<button class="btn btn-warning sm-btn-custom"><i class="fa fa-edit"></i></button> ';
                a = a+'<button class="btn btn-danger sm-btn-custom"><i class="fa fa-trash"></i></button>';
            a = a+'</div>';
        a = a+'</div>';

    $('.add-url-name-main-mail-temp').append(a);
    $('.web-services-add-mail-temp input').val('');
    $('.web-services-add-mail-temp select').val('');
    $('.web-services-add-mail-temp select').val('');
    document.getElementById("upload-xls-mail-temp").value = "";
    $("#upload-xls-filename-mail-temp").text('File Name');
}
});

var input4 = document.getElementById( 'upload-xls-mail-temp' );
var infoArea4 = document.getElementById( 'upload-xls-filename-mail-temp' );

input4.addEventListener( 'change', showFileName4 );

function showFileName4( event ) {
var input4 = event.srcElement;
var fileName4 = input4.files[0].name;
infoArea4.textContent = fileName4;
}

$('#staticDynamicDoc').click(function () {
  var $this = $(this);
  if ($this.is(':checked')) {
      $('.select-temp-dynamic-doc-main').css('display','block');
      $('.select-rule-dynamic-doc-main').css('display','none');
  } else {
      $('.select-temp-dynamic-doc-main').css('display','none');
      $('.select-rule-dynamic-doc-main').css('display','block');
  }
});

$('#dynamicDynamicDoc').click(function () {
  var $this = $(this);
  if ($this.is(':checked')) {
      $('.select-rule-dynamic-doc-main').css('display','block');
      $('.select-temp-dynamic-doc-main').css('display','none');
  } else {
      $('.select-rule-dynamic-doc-main').css('display','none');
      $('.select-temp-dynamic-doc-main').css('display','block');
  }
});

// Clause library Tab
$("body").on("click", ".box-left .list-part h3",function(){
    $(this).parent('.list-part').find('ul').slideToggle();
});
$("body").on("click", ".box-right .list-part h3",function(){
    $(this).parent('.list-part').find('ul').slideToggle();
});

$("body").on("click", ".box-primary-key .list-part h3",function(){
    $(this).parent('.list-part').find('ul').slideToggle();
});

// Template library Tab
$("body").on("click", ".box-left-temp-lib .list-part h3",function(){
    $(this).parent('.list-part').find('ul').slideToggle();
});
$("body").on("click", ".box-right-temp-lib .list-part h3",function(){
    $(this).parent('.list-part').find('ul').slideToggle();
});

// Mail Template Tab
$("body").on("click", ".box-left-mail-temp .list-part h3",function(){
    $(this).parent('.list-part').find('ul').slideToggle();
});
$("body").on("click", ".box-right-mail-temp .list-part h3",function(){
    $(this).parent('.list-part').find('ul').slideToggle();
});

// Clause library Tab
$('.cls-lib-sfdc-previous-btn').click(function () {
  $('.select-sfdc-object-main').css('display','none');
  $('.createNewClauseMain').css('display','block');
});

$('.compose-clause-previous-btn').click(function () {
  if ($('#external-parameter').is(':checked')) {
    $('.compose-clause-main').css('display','none');
    $('.external-parameter-main').css('display','block');
  }else{
    $('.compose-clause-main').css('display','none');
    $('.select-sfdc-object-main').css('display','block');
  }
});

$('.cls-lib-external-para-previous-btn').click(function () {
  $('.external-parameter-main').css('display','none');
  $('.select-sfdc-object-main').css('display','block');
});

// Template library Tab


$('.compose-clause-temp-lib-pre-btn').click(function () {
  if ($('#check-external-parameter-temp').is(':checked')) {
    $('.compose-clause-main-template').css('display','none');
    $('.external-parameter-main-template').css('display','block');
  }else{
    $('.compose-clause-main-template').css('display','none');
    $('.select-sfdc-object-main-template').css('display','block');
  }
});

$('.temp-external-para-pre-btn').click(function () {
  $('.external-parameter-main-template').css('display','none');
  $('.select-sfdc-object-main-template').css('display','block');
});

// Mail Template Tab
$('.mail-temp-sfdc-pre-btn').click(function () {
  $('.select-sfdc-object-mail-temp-main').css('display','none');
  $('.createNewMailTempMain').css('display','block');
});

$('.mail-temp-compose-pre-btn').click(function(){
  $('.external-parameter-mail-temp-main').css('display','none');
  $('.external-parameter-mail-temp-main').css('display','block');
});

$('.mail-temp-compose-pre-btn').click(function () {
  if ($('#external-parameter-mail-temp').is(':checked')) {
    $('.compose-clause-mail-temp-main').css('display','none');
    $('.external-parameter-mail-temp-main').css('display','block');
  }else{
    $('.compose-clause-mail-temp-main').css('display','none');
    $('.select-sfdc-object-mail-temp-main').css('display','block');
  }
});

$('.mail-temp-external-pre-next').click(function () {
  $('.external-parameter-mail-temp-main').css('display','none');
  $('.createNewMailTempMain').css('display','block');
});

$( document ).ready(function() {
  if ($('.upload_file').is(':checked')) {
      $('.upload-file-main').css('display','block');
  }
  


  if ($('.static-dynamic-doc').is(':checked')) {
      $('.select-temp-dynamic-doc-main').css('display','block');
  }

  if ($('.upload_file_parent_cls_lib').is(':checked')) {
      $('.upload-file-main-parnt-cls-lib').css('display','block');
  }
});

$( document ).ready(function() {
  if ($('.upload_file1').is(':checked')) {
      $('.upload-file-main1').css('display','block');
  }
  


  if ($('.static-dynamic-doc').is(':checked')) {
      $('.select-temp-dynamic-doc-main').css('display','block');
  }

  if ($('.upload_file_parent_cls_lib').is(':checked')) {
      $('.upload-file-main-parnt-cls-lib').css('display','block');
  }
});

var ii = 1;
$('body').on('click', '.add-more-btn-workflow', function() { 
  var copy = $(this).parents('.addMore').find('.addMore-copy').html();
  copy = copy.replace("**1**",ii);
  copy = copy.replace("**1**",ii);
  ii++;
  $(this).parents('.addMore').find('.addMore-main').append(copy);
  $('.selectpicker').selectpicker('refresh');
  $(this).parents('.addMore').find('.addMore-sub:last-child').find(".dropdown-toggle:first").css("display","none");
  $(this).parents('.addMore').find('.addMore-sub:last-child').find('.form-group').find(".dropdown-toggle:first").css("display","none");
});


$('.add-more-btn-child-clause-name').click(function(){
  var childCluaseName = document.getElementById("childClauseName").value;
  if(childCluaseName != ''){
    var a = '';
        a = '<a href="">'+childCluaseName+'</a><br/>';
     $('.child-clause-name-list').append(a);
     $('.child-clause-name').val('');
     $('.meta-data-parent-cls-lib').val('');
     $('.description-parent-cls-lib').val('');
  }
});

$("body").on("click", ".workflowCluseLib1",function(){
  var $this = $(this);
  if ($this.is(':checked')) {
      $('.select-workflow-parent-clause-lib').css('display','block');
  } else {
      $('.select-workflow-parent-clause-lib').css('display','none');
  }
});

$('.rules-based').click(function () {
  var $this = $(this);
  if ($this.is(':checked')) {
      $('.select-rule-parent-clause-lib').css('display','block');
  } else {
      $('.select-rule-parent-clause-lib').css('display','none');
  }
});

$('.controller-cluse-lib').click(function () {
  var $this = $(this);
  if ($this.is(':checked')) {
      $('.select-controller-parent-clause-lib').css('display','block');
  } else {
      $('.select-controller-parent-clause-lib').css('display','none');
  }
});

$('.compose-clause-lib-advanced-btn').click(function () {
  $('.compose-clause-main').css('display','none');
  $('.parent-clause-main').css('display','block');
});

$("body").on("click", ".parent-tr",function(){
    $(this).parents('tbody').find('.child-tr').slideToggle();
});

$('.cls-lib-new-cluse-previous-btn').click(function () {
  $('.createNewClauseMain').css('display','none');
  $('.table-clause-library-main').show();
  $('.table-clause-library').show();
  $('.create-new-clause-btn').show();
});

$('.parent-clause-previous-btn').click(function () {
  $('.parent-clause-main').css('display','none');
  $('.compose-clause-main').css('display','block');
});


$('.temp-lib-create-new-previous-btn').click(function () {
  $('.createNewTempMain').css('display','none');
  $('.table-clause-template-main').show();
  $('.table-clause-template').show();
  $('.create-new-template-btn').show();
});

$('#checkAdvancedComposeTempLib').click(function () {
  var $this = $(this);
  if ($this.is(':checked')) {
      $('.select-rule-compose-main-temp-lib').css('display','block');
      $('.select-workflow-compose-main-temp').css('display','block');
      $('.select-workflow-compose-main-temp').css('display','block');
  } else {
      $('.select-rule-compose-main-temp-lib').css('display','none');
      $('.select-workflow-compose-main-temp').css('display','none');
      $('.select-workflow-compose-main-temp').css('display','none');
  }
});

$('.mail-temp-new-pre-btn').click(function () {
  $('.createNewMailTempMain').css('display','none');
  $('.table-mail-template-main').show();
  $('.table-mail-template').show();
  $('.create-new-mail-template-btn').show();
});


$('#checkAdvancedComposeMailTemp').click(function () {
  var $this = $(this);
  if ($this.is(':checked')) {
      $('.select-rule-compose-mail-temp').css('display','block');
      $('.select-workflow-compose-mail-temp').css('display','block');
      $('.select-workflow-compose-mail-temp').css('display','block');
  } else {
      $('.select-rule-compose-mail-temp').css('display','none');
      $('.select-workflow-compose-mail-temp').css('display','none');
      $('.select-workflow-compose-mail-temp').css('display','none');
  }
});

var input5 = document.getElementById( 'upload-attachment' );
var infoArea5 = document.getElementById( 'upload-attachment-filename' );

input5.addEventListener( 'change', showFileName5 );

function showFileName5( event ) {
var input5 = event.srcElement;
var fileName5 = input5.files[0].name;
infoArea5.textContent = fileName5;
}

// var input6 = document.getElementById( 'upload-excel' );
// var infoArea6 = document.getElementById( 'upload-excel-filename' );

// input6.addEventListener( 'change', showFileName6 );

// function showFileName6( event ) {
//   var input6 = event.srcElement;
//   var fileName6 = input6.files[0].name;
//   infoArea6.textContent = fileName6;
// }

// var input7 = document.getElementById( 'upload-excel-parent-cls-lib' );
// var infoArea7 = document.getElementById( 'upload-excel-parent-cls-lib-filename' );

// input7.addEventListener( 'change', showFileName7 );

// function showFileName7( event ) {
//   var input7 = event.srcElement;
//   var fileName7 = input7.files[0].name;
//   infoArea7.textContent = fileName7;
// }

//var input8 = document.getElementById( 'upload-excel-ws-integration' );
//var infoArea8 = document.getElementById( 'upload-excel-ws-integration-filename' );

//input8.addEventListener( 'change', showFileName8 );

function showFileName8( event ) {
  var input8 = event.srcElement;
  var fileName8 = input8.files[0].name;
  infoArea8.textContent = fileName8;
}

$('.upload_file_parent_cls_lib').click(function () {
  var $this = $(this);
  if ($this.is(':checked')) {
      $('.upload-file-main-parnt-cls-lib').css('display','block');
      $('.compose-online-main-parnt-cls-lib').css('display','none');
  }
});
$('.compose_online_parent-cls-lib').click(function () {
  var $this = $(this);
  if ($this.is(':checked')) {
      $('.compose-online-main-parnt-cls-lib').css('display','block');
      $('.upload-file-main-parnt-cls-lib').css('display','none');
  }
});



$("body").on("click", ".click-right-primary-key", function(){
 $(".box-selected-sf-field li.selected").each(function() {
    var heading = $(this).parent("ul").parent("div").find("h3").text();
    var liText = $(this).text();
    $('.primary-key-ext-para-cls-lib').attr('value',liText);

    if($(".box-primary-key").find('h3[data-name="'+heading+'"]').text() != ''){
      $(".box-primary-key").find('h3[data-name="'+heading+'"]').parent("div").find("ul").html("<li>"+liText+"</li>");
    }else{
      $(".box-primary-key").html('<h2 class="box-title">Select Primary Key</h2><div class="list-part"><h3 data-name="'+heading+'">'+heading+'</h3><ul><li>'+liText+'</li></ul></div>');
    }
  });
});

$("body").on("click", ".click-left-primary-key", function(){
 $(".box-primary-key li.selected").each(function() {
    var heading = $(this).parent("ul").parent("div").find("h3").text();
    $('.primary-key-ext-para-cls-lib').attr('value','');

    if ($(this).parent("ul").parent("div").find("ul li").length == 1) {
        $(this).parent("ul").parent("div").remove();
    }else{
      $(this).remove();
    }
  });
});


$("body").on("click", ".click-right-primary-temp-lib", function(){
 $(".box-right-temp-lib li.selected").each(function() {
    var heading = $(this).parent("ul").parent("div").find("h3").text();
    var liText = $(this).text();
    $('.primary-key-ext-para-temp-lib').attr('value',liText);
    if($(".box-primary-temp-lib").find('h3[data-name="'+heading+'"]').text() != ''){
      $(".box-primary-temp-lib").find('h3[data-name="'+heading+'"]').parent("div").find("ul").html("<li>"+liText+"</li>");
    }else{
      $(".box-primary-temp-lib").html('<h2 class="box-title">Select Primary Key</h2><div class="list-part"><h3 data-name="'+heading+'">'+heading+'</h3><ul><li>'+liText+'</li></ul></div>');
    }
  });
});

$("body").on("click", ".click-left-primary-temp-lib", function(){
 $(".box-primary-temp-lib li.selected").each(function() {
    var heading = $(this).parent("ul").parent("div").find("h3").text();
    $('.primary-key-ext-para-temp-lib').attr('value','');

    if ($(this).parent("ul").parent("div").find("ul li").length == 1) {
        $(this).parent("ul").parent("div").remove();
    }else{
      $(this).remove();
    }
  });
});

$("body").on("click", ".click-right-primary-mail-temp", function(){
 $(".box-right-mail-temp li.selected").each(function() {
    var heading = $(this).parent("ul").parent("div").find("h3").text();
    var liText = $(this).text();
    $('.primary-key-ext-para-mail-temp').attr('value',liText);

    if($(".box-primary-mail-temp").find('h3[data-name="'+heading+'"]').text() != ''){
      $(".box-primary-mail-temp").find('h3[data-name="'+heading+'"]').parent("div").find("ul").html("<li>"+liText+"</li>");
    }else{
      $(".box-primary-mail-temp").html('<h2 class="box-title">Select Primary Key</h2><div class="list-part"><h3 data-name="'+heading+'">'+heading+'</h3><ul><li>'+liText+'</li></ul></div>');
    }
  });
});

$("body").on("click", ".click-left-primary-mail-temp", function(){
 $(".box-primary-mail-temp li.selected").each(function() {
    var heading = $(this).parent("ul").parent("div").find("h3").text();
    $('.primary-key-ext-para-mail-temp').attr('value','');

    if ($(this).parent("ul").parent("div").find("ul li").length == 1) {
        $(this).parent("ul").parent("div").remove();
    }else{
      $(this).remove();
    }
  });
});

$('.create-new-document-btn').click(function (e) {
    e.preventDefault();
    $('.create-new-document-btn').css('display','none');
    $('.content-document-main').css('display','block');
    $('.content-btns-document-main').css('display','block');
    $('.table-document-main').css('display','none');
});

$('.document-previous-btn').click(function () {
  $('.content-document-main').css('display','none');
  $('.content-btns-document-main').css('display','none');
  $('.table-document-main').show();
  $('.create-new-document-btn').show();
});


$(document).on('click', '#moveSelected', function(){
  var sName = $('#sName').val();
  var sDisplayed = $('#sDisplayed').val();
  var sLanguage = $('#sLanguage').val();
  var sMainClause = $('#sMainClause').val();
  if(sName == ''){
    alert('Please Enter Name');
  }else if(sDisplayed == ''){
    alert('Please Enter Displayed Name');
  }else if(sLanguage == ''){
    alert('Please Select Language');
  }else if(sMainClause == ''){
    alert('Please Select Type');
  }else{
      var sSubClause = $('#sSubClause').val();
      var sSubClause2 = $('#sSubClause2').val();
      var sSubClause3 = $('#sSubClause3').val();
      if(sMainClause == 'Sub Clause'){
        if(sSubClause == ''){
          alert('Please Select Sub Clause');
        }else{
          var start = $('#selectedTextMove').prop('selectionStart');
          var finish = $('#selectedTextMove').prop('selectionEnd');
          var allText = $('#selectedTextMove').val();
          var sel = allText.substring(start, finish);
          // console.log(sel);
          $('#listClauseMoved').find('ul').append('<li><p style="margin: 0px;font-size: 10px; font-weight: bold; color: #3d93fa;">'+sMainClause+' > '+sSubClause+'</p>'+sName+'<p style="margin: 0px; height: 15px;line-height: 15px; overflow: hidden;"><small>'+sel+'</small></p></li>');
          $('#sName').val('');
          $('#sDisplayed').val('');
          $('#sLanguage').val('');
          $('#sMainClause').val('');
          $('#sSubClause').val('');
          $('#sSubClause2').val('');
          $('#sSubClause3').val('');
        }
      }else if(sMainClause == 'Sub Sub Clause'){
        if(sSubClause == ''){
          alert('Please Select Sub Clause');
        }else if(sSubClause2 == ''){
          alert('Please Select Sub Sub Clause');
        }else{
          var start = $('#selectedTextMove').prop('selectionStart');
          var finish = $('#selectedTextMove').prop('selectionEnd');
          var allText = $('#selectedTextMove').val();
          var sel = allText.substring(start, finish);
          // console.log(sel);
          $('#listClauseMoved').find('ul').append('<li><p style="margin: 0px;font-size: 10px; font-weight: bold; color: #3d93fa;">'+sMainClause+' > '+sSubClause+' > '+sSubClause2+'</p>'+sName+'<p style="margin: 0px; height: 15px;line-height: 15px; overflow: hidden;"><small>'+sel+'</small></p></li>');
          $('#sName').val('');
          $('#sDisplayed').val('');
          $('#sLanguage').val('');
          $('#sMainClause').val('');
          $('#sSubClause').val('');
          $('#sSubClause2').val('');
          $('#sSubClause3').val('');
        }
      }else if(sMainClause == 'Sub Sub Sub Clause'){
        if(sSubClause == ''){
          alert('Please Select Sub Clause');
        }else if(sSubClause2 == ''){
          alert('Please Select Sub Sub Clause');
        }else if(sSubClause3 == ''){
          alert('Please Select Sub Sub Sub Clause');
        }else{
          var start = $('#selectedTextMove').prop('selectionStart');
          var finish = $('#selectedTextMove').prop('selectionEnd');
          var allText = $('#selectedTextMove').val();
          var sel = allText.substring(start, finish);
          // console.log(sel);
          $('#listClauseMoved').find('ul').append('<li><p style="margin: 0px;font-size: 10px; font-weight: bold; color: #3d93fa;">'+sMainClause+' > '+sSubClause+' > '+sSubClause2+' > '+sSubClause3+'</p>'+sName+'<p style="margin: 0px; height: 15px;line-height: 15px; overflow: hidden;"><small>'+sel+'</small></p></li>');
          $('#sName').val('');
          $('#sDisplayed').val('');
          $('#sLanguage').val('');
          $('#sMainClause').val('');
          $('#sSubClause').val('');
          $('#sSubClause2').val('');
          $('#sSubClause3').val('');
        }
      }else{
        var start = $('#selectedTextMove').prop('selectionStart');
          var finish = $('#selectedTextMove').prop('selectionEnd');
          var allText = $('#selectedTextMove').val();
          var sel = allText.substring(start, finish);
          // console.log(sel);
          $('#listClauseMoved').find('ul').append('<li><p style="margin: 0px;font-size: 10px; font-weight: bold; color: #3d93fa;">'+sMainClause+'</p>'+sName+'<p style="margin: 0px; height: 15px;line-height: 15px; overflow: hidden;"><small>'+sel+'</small></p></li>');
          $('#sName').val('');
          $('#sDisplayed').val('');
          $('#sLanguage').val('');
          $('#sMainClause').val('');
          $('#sSubClause').val('');
          $('#sSubClause2').val('');
          $('#sSubClause3').val('');
      }

  }
});

$(document).on('click', '#moveSelectedE', function(){
  var sNameE = $('#sNameE').val();
  var sDisplayedE = $('#sDisplayedE').val();
  var sLanguageE = $('#sLanguageE').val();
  var sMainClauseE = $('#sMainClauseE').val();
  if(sNameE == ''){
    alert('Please Enter Name');
  }else if(sDisplayedE == ''){
    alert('Please Enter Displayed Name');
  }else if(sLanguageE == ''){
    alert('Please Select Language');
  }else if(sMainClauseE == ''){
    alert('Please Select Type');
  }else{
      var sSubClauseE = $('#sSubClauseE').val();
      var sSubClause2E = $('#sSubClause2E').val();
      var sSubClause3E = $('#sSubClause3E').val();
      if(sMainClauseE == 'Sub Clause'){
        if(sSubClauseE == ''){
          alert('Please Select Sub Clause');
        }else{
          var start = $('#selectedTextMoveE').prop('selectionStart');
          var finish = $('#selectedTextMoveE').prop('selectionEnd');
          var allText = $('#selectedTextMoveE').val();
          var sel = allText.substring(start, finish);
          // console.log(sel);
          $('#listClauseMovedE').find('ul').append('<li><p style="margin: 0px;font-size: 10px; font-weight: bold; color: #3d93fa;">'+sMainClauseE+' > '+sSubClauseE+'</p>'+sNameE+'<p style="margin: 0px; height: 15px;line-height: 15px; overflow: hidden;"><small>'+sel+'</small></p></li>');
          $('#sNameE').val('');
          $('#sDisplayedE').val('');
          $('#sLanguageE').val('');
          $('#sMainClauseE').val('');
          $('#sSubClauseE').val('');
          $('#sSubClause2E').val('');
          $('#sSubClause3E').val('');
        }
      }else if(sMainClauseE == 'Sub Sub Clause'){
        if(sSubClauseE == ''){
          alert('Please Select Sub Clause');
        }else if(sSubClause2E == ''){
          alert('Please Select Sub Sub Clause');
        }else{
          var start = $('#selectedTextMoveE').prop('selectionStart');
          var finish = $('#selectedTextMoveE').prop('selectionEnd');
          var allText = $('#selectedTextMoveE').val();
          var sel = allText.substring(start, finish);
          // console.log(sel);
          $('#listClauseMovedE').find('ul').append('<li><p style="margin: 0px;font-size: 10px; font-weight: bold; color: #3d93fa;">'+sMainClauseE+' > '+sSubClauseE+' > '+sSubClause2E+'</p>'+sNameE+'<p style="margin: 0px; height: 15px;line-height: 15px; overflow: hidden;"><small>'+sel+'</small></p></li>');
          $('#sNameE').val('');
          $('#sDisplayedE').val('');
          $('#sLanguageE').val('');
          $('#sMainClauseE').val('');
          $('#sSubClauseE').val('');
          $('#sSubClause2E').val('');
          $('#sSubClause3E').val('');
        }
      }else if(sMainClauseE == 'Sub Sub Sub Clause'){
        if(sSubClauseE == ''){
          alert('Please Select Sub Clause');
        }else if(sSubClause2E == ''){
          alert('Please Select Sub Sub Clause');
        }else if(sSubClause3E == ''){
          alert('Please Select Sub Sub Sub Clause');
        }else{
          var start = $('#selectedTextMoveE').prop('selectionStart');
          var finish = $('#selectedTextMoveE').prop('selectionEnd');
          var allText = $('#selectedTextMoveE').val();
          var sel = allText.substring(start, finish);
          // console.log(sel);
          $('#listClauseMovedE').find('ul').append('<li><p style="margin: 0px;font-size: 10px; font-weight: bold; color: #3d93fa;">'+sMainClauseE+' > '+sSubClauseE+' > '+sSubClause2E+' > '+sSubClause3E+'</p>'+sNameE+'<p style="margin: 0px; height: 15px;line-height: 15px; overflow: hidden;"><small>'+sel+'</small></p></li>');
          $('#sNameE').val('');
          $('#sDisplayedE').val('');
          $('#sLanguageE').val('');
          $('#sMainClauseE').val('');
          $('#sSubClauseE').val('');
          $('#sSubClause2E').val('');
          $('#sSubClause3E').val('');
        }
      }else{
        var start = $('#selectedTextMoveE').prop('selectionStart');
          var finish = $('#selectedTextMoveE').prop('selectionEnd');
          var allText = $('#selectedTextMoveE').val();
          var sel = allText.substring(start, finish);
          // console.log(sel);
          $('#listClauseMovedE').find('ul').append('<li><p style="margin: 0px;font-size: 10px; font-weight: bold; color: #3d93fa;">'+sMainClauseE+'</p>'+sNameE+'<p style="margin: 0px; height: 15px;line-height: 15px; overflow: hidden;"><small>'+sel+'</small></p></li>');
          $('#sNameE').val('');
          $('#sDisplayedE').val('');
          $('#sLanguageE').val('');
          $('#sMainClauseE').val('');
          $('#sSubClauseE').val('');
          $('#sSubClause2E').val('');
          $('#sSubClause3E').val('');
      }

  }
});

/********uploader******** */
function uploadFile() {
  var data = new FormData();
  $.each($('#file-open-one-one')[0].files, function (i, file) {
    data.append('file-' + i, file);
  });

  $.ajax({
    url: 'http://localhost:2000/api/uploadfile',
    data: data,
    cache: false,
    contentType: false,
    processData: false,
    method: 'POST',
    type: 'POST', // For jQuery < 1.9
    success: function (res) {
      if (res) {
        var url = 'http://localhost/doctiger/assets/docs/';
        $('.editor-view-one').css('display','block');
        $('.drop-down-up-file').css('display','none');
        $('.tabcontent-btn-menu-one').trigger('click');
        CKEDITOR.instances['editor2'].setData(res)
      }
    },
    error: function (err) {
      alert(err.responseText);
    }

  });
}

// setting fields/functions value inside the editor 
function setTextinEditor(element, eleType){
  let  startSymbol = (eleType === 'field')?'<<':'${'
  let  endSymbol = (eleType === 'field')?'>>':'$}'
  let txtval= startSymbol + element.innerText + endSymbol;
  CKEDITOR.instances['editor2'].insertText(txtval);
}

function setTextCoverImages(){
  var txtval = $('#coverimages').children("option:selected").val();
  if(txtval !== '0'){
    CKEDITOR.instances['editor2'].insertText('<<'+txtval +'>>');
  }
}

function setTextQRCode(){
    CKEDITOR.instances['editor2'].insertText('<<qrcode>>');
}

function setLogoBlocks() {
  var txtval = $('#logoImages').children("option:selected").val();
  if(txtval !== '0'){
    CKEDITOR.instances['editor2'].insertText('<<'+txtval +'>>');
  }
}

function downloadDoc(){
  var header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' "+
       "xmlns:w='urn:schemas-microsoft-com:office:word' "+
       "xmlns='http://www.w3.org/TR/REC-html40'>"+
       "<head><meta charset='utf-8'><title>Export HTML to Word Document with JavaScript</title></head><body>";
  var footer = "</body></html>";
  var sourceHTML = header+ CKEDITOR.instances["editor2"].getData()+footer;
  
  var source = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(sourceHTML);
  var fileDownload = document.createElement("a");
  document.body.appendChild(fileDownload);
  fileDownload.href = source;
  fileDownload.download = 'document.docx';
  fileDownload.click();
  document.body.removeChild(fileDownload);
}

function saveToList(){
  debugger
  saveTodisk();
  let editortxt = CKEDITOR.instances.editor1.document.getBody().getText();
  var fieldResultList = getFromBetween.get(editortxt,"<<",">>");
   if(fieldResultList.length > 0){
    createFieldsList(fieldResultList);
   }
   var functionResultList = getFromBetween.get(editortxt,"${","}$");
   if(functionResultList.length > 0){
    createFunctionList(functionResultList);
   }
}

function createFieldsList(list){
  var ul = document.getElementById("fieldsList");
  list.forEach(element => {
      if($('#fieldsList')[0].children.length > 0){
        var isExist = false;
        $('#fieldsList > li').each(function(){
          var text = $(this).text();
            if(text.indexOf(element) >= 0){
              isExist = true;
            }  
      });
          if(!isExist){
            var li = document.createElement("li");
            li.setAttribute('class','my-button-second');
            var a = document.createElement('a');
            var linkText = document.createTextNode(element);
            a.appendChild(linkText);
            li.appendChild(a);
            ul.appendChild(li)
          }

      }
  });
}


function createFunctionList(list){
  var maindiv = document.getElementById("functionsList");
  list.forEach(element => {
      if($('#functionsList')[0].children.length > 0){
        var isExist = false;
        $('#functionsList > a').each(function(){
          var text = $(this).text();
            if(text.indexOf(element) >= 0){
              isExist = true;
            }  
      });
          if(!isExist){
            var a = document.createElement("a");
            var divele = document.createElement('div');
            var p = document.createElement('p')
            var ptext = document.createTextNode(element);
            p.appendChild(ptext);
            divele.setAttribute('class','blog-box');
            divele.appendChild(p);
            a.appendChild(divele)
            maindiv.appendChild(a)
          }

      }
  });
}



var getFromBetween = {
  results:[],
  string:"",
  getFromBetween:function (sub1,sub2) {
      if(this.string.indexOf(sub1) < 0 || this.string.indexOf(sub2) < 0) return false;
      var SP = this.string.indexOf(sub1)+sub1.length;
      var string1 = this.string.substr(0,SP);
      var string2 = this.string.substr(SP);
      var TP = string1.length + string2.indexOf(sub2);
      return this.string.substring(SP,TP);
  },
  removeFromBetween:function (sub1,sub2) {
      if(this.string.indexOf(sub1) < 0 || this.string.indexOf(sub2) < 0) return false;
      var removal = sub1+this.getFromBetween(sub1,sub2)+sub2;
      this.string = this.string.replace(removal,"");
  },
  getAllResults:function (sub1,sub2) {
      // first check to see if we do have both substrings
      if(this.string.indexOf(sub1) < 0 || this.string.indexOf(sub2) < 0) return;

      // find one result
      var result = this.getFromBetween(sub1,sub2);
      // push it to the results array
      this.results.push(result);
      // remove the most recently found one from the string
      this.removeFromBetween(sub1,sub2);

      // if there's more substrings
      if(this.string.indexOf(sub1) > -1 && this.string.indexOf(sub2) > -1) {
          this.getAllResults(sub1,sub2);
      }
      else return;
  },
  get:function (string,sub1,sub2) {
      this.results = [];
      this.string = string;
      this.getAllResults(sub1,sub2);
      return this.results;
  }

 
};

function saveTodisk(){
  let htmldata = CKEDITOR.instances['editor1'].getData();
    var data = {content: htmldata};
  $.ajax({
    url: 'http://localhost:2000/api/savetodisk',
    data: JSON.stringify(data),
    cache: false,
    contentType: 'application/json',
    processData: false,
    method: 'POST',
    type: 'POST', // For jQuery < 1.9
    success: function (res) {
      if (res) {
        
      }
    },
    error: function (err) {
      alert(err.responseText);
    }

  });

  }

  function savetoDisk(){
  let htmldata = CKEDITOR.instances['editor2'].getData();
  while(htmldata.indexOf('<table>') != -1){
  htmldata = htmldata.replace('<table>','<table border="1" cellpadding="1" cellspacing="1">');
  }
    var data = {content: htmldata};
	$.ajax({
    url: 'http://localhost:2000/api/savetodisk',
    data: JSON.stringify(data),
    cache: false,
    contentType: 'application/json',
    processData: false,
    method: 'POST',
    type: 'POST', // For jQuery < 1.9
    success: function (res) {
      if (res) {
        
      }
    },
    error: function (err) {
      alert(err.responseText);
    }

  });

  }
